# FinanFlow - Engenharia Reversa (Benchmark)

## Objetivo
Extrair requisitos funcionais observados nas telas de referência para servir de benchmark do FinanFlow.

## Funcionalidades identificadas

### Dashboard
- Saudação personalizada.
- Resumo de gastos do mês.
- Lista de transações recentes.
- Atalho para todas as transações.
- Cards principais:
  - Organizador Financeiro
  - Gastos Categorizados
  - Relatório Mensal
  - Cofrinho (reserva automática)

### Agregação Financeira
- Conectar múltiplos bancos.
- Exibir saldo consolidado.
- Mostrar distribuição por instituição.
- Visualizar assinaturas recorrentes.

### Gestão de Gastos
- Categorização automática.
- Visualização por gráfico.
- Total gasto por período.
- Drill-down por categoria.
- Histórico mensal.

### Filtros
- Filtrar por banco.
- Filtrar por tipo de transação:
  - Crédito
  - Débito
  - Pix
  - Boleto
  - Dinheiro
  - Outros

## Backlog sugerido

### MVP
- Agregação bancária
- Importação de transações
- Categorização automática
- Dashboard
- Filtros
- Relatório mensal

### V2
- Cofrinho automático
- Detecção de assinaturas
- Insights inteligentes
- Alertas de orçamento
- IA para classificação e recomendações

## Estrutura
```
FinanFlow/
 ├── README.md
 ├── notes.md
 └── screenshots/
```
