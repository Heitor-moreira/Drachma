# Notes

## Requisitos Funcionais

RF-001 Agregar contas bancárias.
RF-002 Consolidar saldo.
RF-003 Importar transações automaticamente.
RF-004 Categorizar transações.
RF-005 Exibir dashboard mensal.
RF-006 Mostrar últimas transações.
RF-007 Relatório mensal.
RF-008 Filtrar por banco.
RF-009 Filtrar por tipo de transação.
RF-010 Detectar assinaturas.
RF-011 Exibir distribuição de gastos por categoria.
RF-012 Navegação por mês.
RF-013 Reserva financeira (cofrinho).

## Requisitos Não Funcionais

- Atualização rápida.
- Interface mobile-first.
- Suporte a múltiplas contas.
- Escalável para novos bancos.
- Gráficos responsivos.

## Oportunidades para superar o benchmark

- IA explicando cada gasto.
- Busca em linguagem natural.
- Integração com Obsidian.
- Modelos locais para classificação.
- Regras personalizadas.
- Timeline financeira.
- Orçamento preditivo.
